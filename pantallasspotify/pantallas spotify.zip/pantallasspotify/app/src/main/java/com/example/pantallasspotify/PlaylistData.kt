package com.example.pantallasspotify

data class PlaylistData(
    val title : String,
    val seguidores : Int,
    val imagen : String
)
