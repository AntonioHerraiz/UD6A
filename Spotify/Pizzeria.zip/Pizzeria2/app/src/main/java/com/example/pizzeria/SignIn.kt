package com.example.pizzeria

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SignIn : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        for (user in userList){
            //if (user.email ==
        }
    }


}