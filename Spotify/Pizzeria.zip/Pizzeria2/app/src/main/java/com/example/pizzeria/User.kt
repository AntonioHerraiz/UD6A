package com.example.pizzeria

data class User(
    val name: String,
    val email: String,
    val password: String
)
