package com.utad.tema17

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private lateinit var rvGeneros: RecyclerView
    val TAG = "MainActivity"
    private var adapter: GenresAdapter? = null
    var data: ArrayList<GenresResponse.Genre> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView( R.layout.activity_main)

        rvGeneros = findViewById<RecyclerView>(R.id.rvGeneros)

        val mLayoutManager = GridLayoutManager(this, 2)
        rvGeneros.layoutManager = mLayoutManager
        adapter = GenresAdapter(data)

        rvGeneros.adapter = adapter



        ApiRest.initService()
        getGenres()
    }
    // SIGUIENTE DIAPOSITIVA
    // fun getGenres()
    private fun getGenres() {
        val call = ApiRest.service.getGenres()
        call.enqueue(object : Callback<GenresResponse> {
            override fun onResponse(call: Call<GenresResponse>, response: Response<GenresResponse>) {
                val body = response.body()
                if (response.isSuccessful && body != null) {
                    Log.i(TAG, body.toString())
                    data.clear()
                    data.addAll(body.genres)
                    // Imprimir aqui el listado con logs
                    Log.d(TAG,data.toString())
                    adapter?.notifyDataSetChanged()
                } else {
                    Log.e(TAG, response.errorBody()?.string()?.let { Log.e(TAG, it) }.toString())
                }
            }
            override fun onFailure(call: Call<GenresResponse>, t: Throwable) {
                Log.e(TAG, t.message.toString())
            }
        })
    }
}